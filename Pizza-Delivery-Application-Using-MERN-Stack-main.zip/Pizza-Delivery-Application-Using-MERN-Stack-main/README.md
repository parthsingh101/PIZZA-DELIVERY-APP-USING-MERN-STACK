# Tech Stack: MongoDB, Express.js, React.js, Node.js
## • Designed and implemented Pizza delivery application using HTML, CSS, JavaScript, React.js,Node.js, Express.js, MongoDB.
## • Enabled user to order different size and categories of Pizza based on the user taste.
